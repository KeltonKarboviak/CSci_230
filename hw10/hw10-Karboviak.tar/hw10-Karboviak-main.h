/*
 * File:   hw10-Karboviak-main.h
 * Author: Kelton Karboviak
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


typedef unsigned char uchar;

int main(int argc, char** argv);