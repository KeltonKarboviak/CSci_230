/*
 * File:   hw10-Karboviak-reverse.h
 * Author: Kelton Karboviak
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifndef TEST1
	typedef unsigned char uchar;
#endif

int DisplayReversePrimer(uchar *dna, int dnaSize, int length, int end, int count);